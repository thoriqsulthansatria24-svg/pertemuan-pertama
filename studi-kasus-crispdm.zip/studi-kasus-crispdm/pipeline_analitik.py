"""
Studi Kasus: Dari Data Berantakan ke Keputusan, Analitik 4 Tingkat pada PT Maju Bersama (fiktif)
Berdasarkan kuliah praktisi "Informatics Practitioner Lecture Series 2026" oleh Andria Arisal (BRIN).

Alur mengikuti kerangka CRISP-DM:
  1. Business Understanding : pendapatan naik, tetapi laba bersih turun dan piutang membengkak. Mengapa?
  2. Data Understanding     : membuat data transaksi mentah yang sengaja berantakan (data/data_mentah.csv)
  3. Data Preparation       : membersihkan data dan mencatat semua temuan (tahap paling krusial)
  4. Modeling               : analitik deskriptif, diagnostik, prediktif (4 model dibandingkan), preskriptif
  5. Evaluation             : metrik model pada data yang lebih baru + antrean verifikasi oleh manusia
  6. Deployment             : dashboard web (docs/index.html) yang dibangun ulang otomatis oleh GitHub Actions
Semua data di sini SINTETIS (hasil simulasi), bukan data perusahaan nyata.
"""
import json
import re
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

SEED = 2026
AWAL, CUTOFF, N_BULAN = pd.Timestamp("2024-10-01"), pd.Timestamp("2026-09-30"), 24
DATA, DOCS = Path("data"), Path("docs")
SEGMEN = ["Korporasi", "UMKM", "Pemerintah"]
# produk: (harga list, rasio HPP awal, kenaikan rasio HPP per bulan)
PRODUK = {"Perangkat Jaringan": (4.5e6, .63, 0.0), "Server & Storage": (18e6, .68, .007),
          "Lisensi Software": (6e6, .38, 0.0), "Jasa Implementasi": (9e6, .50, 0.0)}
OPEX_TETAP, OPEX_NAIK, OPEX_VAR = 560e6, 32e6, 0.03   # asumsi biaya operasional (simulasi)
PENYISIHAN = 0.02          # penyisihan piutang per bulan dari saldo lewat jatuh tempo > 30 hari
TINGGI, SEDANG = 0.85, 0.60  # ambang risiko keterlambatan
BATAS_DISKON, MARGIN_TIPIS, ASUMSI_BATAL, ASUMSI_EFEK = 0.10, 0.15, 0.10, 0.30
BLN = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]


# ---------------------------------------------------------------- 2. DATA UNDERSTANDING
def buat_data_mentah():
    """Simulasi transaksi invoice 24 bulan, lalu dikotori seperti data lapangan."""
    rng = np.random.default_rng(SEED)
    inti = ["Aneka Jaya", "Sumber Makmur", "Karya Nusantara", "Bumi Sentosa", "Cahaya Abadi", "Mitra Sejahtera",
            "Garuda Teknik", "Surya Mandiri", "Tirta Lestari", "Harapan Baru", "Maju Terus", "Prima Solusi",
            "Delta Pratama", "Citra Mandala", "Fajar Utama", "Graha Data", "Indo Konektivitas", "Jaya Digital",
            "Kencana Raya", "Lintas Sumatera", "Multi Daya", "Nusa Teknologi", "Optima Karya", "Pelita Insan",
            "Rajawali Sakti", "Sinar Terang", "Tunas Muda", "Unggul Perkasa", "Dinas Kominfo Kota A",
            "Dinas Pendidikan Kab B", "RSUD Kota C", "Pemkab D", "Universitas E", "Dinas PUPR F",
            "Badan Pendapatan G", "Dinas Kesehatan H"]
    seg = ["Korporasi"] * 12 + ["UMKM"] * 16 + ["Pemerintah"] * 8
    pref = {"Korporasi": "PT ", "UMKM": "CV ", "Pemerintah": ""}
    plg = pd.DataFrame({"resmi": [pref[s] + n for s, n in zip(seg, inti)], "segmen": seg,
                        "bobot": rng.uniform(.5, 1.5, 36), "off": rng.normal(0, 8, 36)})
    p_plg = (plg.bobot / plg.bobot.sum()).to_numpy()
    base, drift = {"Korporasi": -8, "UMKM": 2, "Pemerintah": 0}, {"Korporasi": .45, "UMKM": .1, "Pemerintah": 1.3}
    termin = {"Korporasi": [30, 45], "UMKM": [14, 30], "Pemerintah": [30, 60]}
    qty_rata = {"Korporasi": 6, "UMKM": 2, "Pemerintah": 5}
    nama_p, p_prod = list(PRODUK), [.35, .2, .3, .15]
    rows = []
    for t in range(N_BULAN):
        awal = AWAL + pd.DateOffset(months=t)
        hari = ((awal + pd.DateOffset(months=1)) - awal).days
        for _ in range(55 + 3 * t):
            c = plg.iloc[rng.choice(36, p=p_plg)]
            s, prod = c.segmen, nama_p[rng.choice(4, p=p_prod)]
            h0, cr, dr = PRODUK[prod]
            harga = h0 * (1 + .003 * t) * (1 + rng.normal(0, .08))
            qty = 1 + rng.poisson(qty_rata[s])
            disk = float(np.clip(rng.normal(.04 + .003 * t if s == "Korporasi" else .02, .015), 0, .25))
            kotor = qty * harga
            tgl = awal + pd.Timedelta(days=int(rng.integers(0, hari)))
            trm = int(rng.choice(termin[s]))
            jt = tgl + pd.Timedelta(days=trm)
            delay = base[s] + c.off + drift[s] * t + 3 * np.log(kotor * (1 - disk) / 20e6) + rng.normal(0, 12) + (rng.random() < .04) * rng.exponential(45)
            bayar = max(jt + pd.Timedelta(days=int(round(delay))), tgl + pd.Timedelta(days=1))
            bayar = pd.NaT if bayar > CUTOFF else bayar
            hpp = kotor * float(np.clip(cr + dr * t + rng.normal(0, .01), .2, .95))
            rows.append(dict(tanggal=tgl, pelanggan=c.resmi, segmen=s, produk=prod, qty=qty, harga=harga,
                             diskon_pct=round(disk, 3), termin_hari=trm, bayar=bayar, biaya_pokok=round(hpp)))
    d = pd.DataFrame(rows)
    d.insert(0, "no_invoice", [f"INV-{i:05d}" for i in range(1, len(d) + 1)])
    n = len(d)
    # --- pengotoran data (meniru kondisi lapangan) ---
    d.loc[rng.choice(n, 6, replace=False), "harga"] *= 10                    # salah ketik: nol berlebih
    d.loc[rng.choice(n, int(.012 * n), replace=False), "qty"] *= -1           # retur / salah input
    dibayar = d.index[d.bayar.notna()]
    idx = rng.choice(dibayar, 4, replace=False)
    d.loc[idx, "bayar"] = d.loc[idx, "tanggal"] - pd.Timedelta(days=5)        # bayar sebelum invoice
    r = rng.random(n)
    d["pelanggan"] = np.where(r < .12, d.pelanggan.str.lower() + " ", np.where(
        r < .22, d.pelanggan.str.replace(r"^(PT|CV) (.*)$", r"\2 \1", regex=True),
        np.where(r < .27, d.pelanggan.str.upper(), d.pelanggan)))
    def tgl_str(ts, u):
        if pd.isna(ts):
            return ""
        return ts.strftime("%Y-%m-%d" if u < .7 else "%d/%m/%Y" if u < .9 else "%d %b %Y")
    d["tanggal"] = [tgl_str(x, u) for x, u in zip(d.tanggal, rng.random(n))]
    d["bayar"] = [tgl_str(x, u) for x, u in zip(d.bayar, rng.random(n))]
    d["harga"] = [("Rp " + f"{round(h):,}".replace(",", ".")) if u < .3 else str(round(h))
                  for h, u in zip(d.harga, rng.random(n))]
    d.loc[rng.random(n) < .02, "harga"] = ""                                  # harga hilang
    d.loc[rng.random(n) < .04, "segmen"] = np.nan                             # segmen kosong
    d = pd.concat([d, d.sample(frac=.02, random_state=SEED)]).sample(frac=1, random_state=SEED)  # duplikat
    d = d.rename(columns={"tanggal": "tanggal_invoice", "harga": "harga_satuan", "bayar": "tanggal_bayar"})
    DATA.mkdir(exist_ok=True)
    d.to_csv(DATA / "data_mentah.csv", index=False)
    return d


# ---------------------------------------------------------------- 3. DATA PREPARATION
def parse_tgl(s):
    if pd.isna(s) or s == "":
        return pd.NaT
    for f in ("%Y-%m-%d", "%d/%m/%Y", "%d %b %Y"):
        try:
            return pd.Timestamp(datetime.strptime(s, f))
        except ValueError:
            pass
    return pd.NaT


def kunci(s):
    t = re.sub(r"[^a-z0-9 ]", " ", str(s).lower())
    return " ".join(sorted(w for w in t.split() if w not in {"pt", "cv", "ud"}))


def bersihkan():
    raw = pd.read_csv(DATA / "data_mentah.csv", dtype=str)
    log = []
    add = lambda tahap, temuan, tindakan, n: log.append(dict(tahap=tahap, temuan=temuan, tindakan=tindakan, jumlah=int(n)))
    d = raw.drop_duplicates().copy()
    add("Duplikat", "Baris invoice yang sama tercatat dua kali", "Dihapus, disisakan satu", len(raw) - len(d))
    fmt = raw.tanggal_invoice.map(lambda s: "ISO" if re.match(r"\d{4}-", s) else "dd/mm/yyyy" if "/" in s else "dd Mon yyyy")
    add("Format tanggal", "Tiga format tanggal bercampur (2025-03-12, 12/03/2025, 12 Mar 2025)", "Diseragamkan ke satu tipe tanggal",
        (fmt != "ISO").sum())
    d["tanggal"], d["bayar"] = d.tanggal_invoice.map(parse_tgl), d.tanggal_bayar.map(parse_tgl)
    d["_k"] = d.pelanggan.map(kunci)
    n_var = d.pelanggan.nunique()
    canon = d.groupby("_k").pelanggan.agg(lambda x: x.str.strip().mode().iat[0])
    d["pelanggan"] = d._k.map(canon)
    add("Nama pelanggan", f"{n_var} variasi penulisan (huruf besar/kecil, urutan PT/CV) untuk {d.pelanggan.nunique()} pelanggan",
        "Distandarkan lewat kunci nama", n_var - d.pelanggan.nunique())
    d["harga"] = pd.to_numeric(d.harga_satuan.str.replace(r"[^\d]", "", regex=True), errors="coerce")
    d["qty"] = pd.to_numeric(d.qty)
    for k in ("diskon_pct", "termin_hari", "biaya_pokok"):
        d[k] = pd.to_numeric(d[k])
    add("Format angka", "Harga ditulis sebagai teks \"Rp 4.500.000\" bercampur angka biasa", "Dikonversi ke numerik",
        d.harga_satuan.str.startswith("Rp").sum())
    kosong = d.segmen.isna()
    modus = d.dropna(subset=["segmen"]).groupby("pelanggan").segmen.agg(lambda x: x.mode().iat[0])
    d["segmen"] = d.segmen.fillna(d.pelanggan.map(modus))
    add("Nilai kosong", "Segmen pelanggan kosong", "Diisi dari segmen pelanggan yang sama", kosong.sum())
    med = d.groupby("produk").harga.transform("median")
    hk = d.harga.isna()
    d["harga"] = d.harga.fillna(med)
    add("Nilai kosong", "Harga satuan kosong", "Diimputasi dengan median harga produk", hk.sum())
    d["flag"] = ""
    for cond, txt in [(d.qty <= 0, "Qty negatif/nol (kemungkinan retur)"), (d.harga / med > 4, "Harga satuan > 4x median produk"),
                      (d.bayar < d.tanggal, "Tanggal bayar sebelum tanggal invoice")]:
        d.loc[cond.fillna(False), "flag"] += txt + "; "
    add("Anomali", "Qty negatif, harga tidak wajar, atau tanggal bayar tidak masuk akal",
        "Tidak dihapus otomatis: dikeluarkan dari analisis dan dikirim ke antrean verifikasi manusia", (d.flag != "").sum())
    antrean = d[d.flag != ""][["no_invoice", "pelanggan", "produk", "qty", "harga", "flag"]].copy()
    d = d[d.flag == ""].copy()
    d["kotor"] = d.qty * d.harga
    d["diskon"] = d.kotor * d.diskon_pct
    d["bersih"] = d.kotor - d.diskon
    d["hpp"] = d.biaya_pokok
    d["jt"] = d.tanggal + pd.to_timedelta(d.termin_hari, unit="D")
    d["t"] = (d.tanggal.dt.year - AWAL.year) * 12 + d.tanggal.dt.month - AWAL.month
    d["periode"] = np.where(d.t < 12, "A", "B")
    d["telat"] = np.where(d.jt < CUTOFF, (d.bayar.isna() | (d.bayar > d.jt)).astype(float), np.nan)
    return d.sort_values("tanggal").reset_index(drop=True), antrean, log


# ---------------------------------------------------------------- 4a. DESKRIPTIF
def keuangan(d):
    rows = []
    for i in range(N_BULAN):
        a = AWAL + pd.DateOffset(months=i)
        z = a + pd.DateOffset(months=1) - pd.Timedelta(days=1)
        m = d[(d.tanggal >= a) & (d.tanggal <= z)]
        buka = d[(d.tanggal <= z) & (d.bayar.isna() | (d.bayar > z))]
        piutang, lewat = buka.bersih.sum(), buka[buka.jt < z - pd.Timedelta(days=30)].bersih.sum()
        bersih = m.bersih.sum()
        opex = OPEX_TETAP + OPEX_NAIK * i + OPEX_VAR * bersih
        prov = PENYISIHAN * lewat
        rows.append(dict(bulan=f"{BLN[a.month - 1]} {str(a.year)[2:]}", kotor=m.kotor.sum(), diskon=m.diskon.sum(),
                         bersih=bersih, hpp=m.hpp.sum(), opex=opex, prov=prov,
                         laba=bersih - m.hpp.sum() - opex - prov, piutang=piutang, dso=piutang / bersih * 30))
    return pd.DataFrame(rows)


def aging(d):
    buka = d[d.bayar.isna()].copy()
    hari = (CUTOFF - buka.jt).dt.days
    kel = pd.cut(hari, [-9999, 0, 30, 60, 90, 9999], labels=["Belum jatuh tempo", "1-30 hari", "31-60 hari", "61-90 hari", "> 90 hari"])
    return buka.groupby(kel, observed=False).bersih.sum().round(0).to_dict()


# ---------------------------------------------------------------- 4b. DIAGNOSTIK
def diagnostik(d, m):
    A, B = m.iloc[:12], m.iloc[12:]
    kom = ["kotor", "diskon", "hpp", "opex", "prov"]
    dl = {k: B[k].sum() - A[k].sum() for k in kom}
    air = [("Laba bersih 12 bulan pertama", A.laba.sum(), "total"), ("Kenaikan penjualan kotor", dl["kotor"], "delta"),
           ("Tambahan diskon", -dl["diskon"], "delta"), ("Tambahan HPP", -dl["hpp"], "delta"),
           ("Tambahan biaya operasional", -dl["opex"], "delta"), ("Tambahan penyisihan piutang", -dl["prov"], "delta"),
           ("Laba bersih 12 bulan terakhir", B.laba.sum(), "total")]
    produk = []
    for p in PRODUK:
        r = {"produk": p}
        for k in "AB":
            x = d[(d.produk == p) & (d.periode == k)]
            r["margin" + k] = (x.bersih.sum() - x.hpp.sum()) / x.bersih.sum()
            r["omzet" + k] = x.bersih.sum()
        produk.append(r)
    seg = []
    for s in SEGMEN:
        r = {"segmen": s}
        for k in "AB":
            x = d[(d.segmen == s) & (d.periode == k)]
            lab = x[x.telat.notna()]
            bayar = lab[lab.bayar.notna()]
            r["diskon" + k] = x.diskon.sum() / x.kotor.sum()
            r["telat" + k] = lab.telat.mean()
            r["hari" + k] = (bayar.bayar - bayar.jt).dt.days.mean()
        seg.append(r)
    return dict(waterfall=[dict(label=a, nilai=b, tipe=c) for a, b, c in air], produk=produk, segmen=seg)


# ---------------------------------------------------------------- 4c. PREDIKTIF
def fitur(df, ref, loo=False):
    X = pd.DataFrame({"log_nilai": np.log(df.bersih), "termin": df.termin_hari, "diskon": df.diskon_pct, "t": df.t}, index=df.index)
    for s in SEGMEN:
        X["seg_" + s] = (df.segmen == s).astype(int)
    for p in PRODUK:
        X["prd_" + p] = (df.produk == p).astype(int)
    g = ref.groupby("pelanggan").telat.agg(["sum", "count"])
    s, n = df.pelanggan.map(g["sum"]).fillna(0), df.pelanggan.map(g["count"]).fillna(0)
    if loo:
        s, n = s - df.telat, n - 1
    gm = ref.telat.mean()
    X["rate_pelanggan"] = (s + 3 * gm) / (n + 3)   # tingkat telat historis pelanggan (dihaluskan)
    return X


def prediktif(d):
    lab = d[d.telat.notna()].sort_values("jt").copy()
    lab["telat"] = lab.telat.astype(int)
    baru = d[d.bayar.isna() & (d.jt >= CUTOFF)].copy()
    cut = int(len(lab) * .75)
    tr, te = lab.iloc[:cut], lab.iloc[cut:]
    Xtr, Xte = fitur(tr, tr, loo=True), fitur(te, tr)
    model = {"Regresi Logistik": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)),
             "Pohon Keputusan": DecisionTreeClassifier(max_depth=5, min_samples_leaf=20, random_state=SEED),
             "Random Forest": RandomForestClassifier(300, max_depth=8, min_samples_leaf=10, random_state=SEED, n_jobs=-1),
             "Gradient Boosting": GradientBoostingClassifier(random_state=SEED)}
    hasil = []
    for nama, m in model.items():
        m.fit(Xtr, tr.telat)
        p, y = m.predict_proba(Xte)[:, 1], m.predict(Xte)
        hasil.append(dict(model=nama, akurasi=accuracy_score(te.telat, y), presisi=precision_score(te.telat, y),
                          recall=recall_score(te.telat, y), f1=f1_score(te.telat, y), auc=roc_auc_score(te.telat, p)))
    terbaik = max(hasil, key=lambda r: r["auc"])["model"]
    final = model[terbaik].fit(fitur(lab, lab, loo=True), lab.telat)       # latih ulang dengan semua data berlabel
    baru["proba"] = final.predict_proba(fitur(baru, lab))[:, 1]
    baru["tingkat"] = np.where(baru.proba >= TINGGI, "Tinggi", np.where(baru.proba >= SEDANG, "Sedang", "Rendah"))
    info = dict(n_latih=len(tr), n_uji=len(te), proporsi_telat=lab.telat.mean(), baseline=max(te.telat.mean(), 1 - te.telat.mean()), terbaik=terbaik, hasil=hasil)
    return lab, baru, info


# ---------------------------------------------------------------- 4d. PRESKRIPTIF
def preskriptif(d, lab, baru):
    tindakan = {"Tinggi": "Telepon H-10, minta konfirmasi tanggal bayar, eskalasi ke atasan pelanggan",
                "Sedang": "Kirim pengingat H-7 dan konfirmasi penerimaan invoice", "Rendah": "Tidak perlu tindakan khusus"}
    top = baru.assign(harapan=baru.proba * baru.bersih).sort_values("harapan", ascending=False).head(12)
    top = [dict(no=r.no_invoice, pelanggan=r.pelanggan, produk=r.produk, nilai=r.bersih, jt=r.jt.strftime("%d %b %Y"),
                proba=r.proba, tingkat=r.tingkat, tindakan=tindakan[r.tingkat]) for r in top.itertuples()]
    buka = d[d.bayar.isna()].copy()
    pr = baru.set_index("no_invoice").proba
    buka["p"] = buka.no_invoice.map(pr).fillna(1.0)       # sudah lewat jatuh tempo = pasti telat
    rate = lab.groupby("pelanggan").telat.mean()
    plg = buka.groupby(["pelanggan", "segmen"]).apply(lambda x: pd.Series(dict(
        terbuka=x.bersih.sum(), berisiko=(x.p * x.bersih).sum())), include_groups=False).reset_index()
    plg["rate"] = plg.pelanggan.map(rate)
    plg["saran"] = np.where(plg.rate >= .7, "Minta uang muka / perpendek termin",
                            np.where(plg.rate >= .4, "Jadwalkan penagihan rutin + pengingat", "Pantau"))
    plg = plg.sort_values("berisiko", ascending=False).head(8)
    tinggi_sedang = baru[baru.tingkat != "Rendah"]
    harapan = (tinggi_sedang.proba * tinggi_sedang.bersih).sum()
    x = d[(d.periode == "B") & (d.diskon_pct > BATAS_DISKON) & ((d.bersih - d.hpp) / d.bersih < MARGIN_TIPIS)]
    hemat = ((x.diskon_pct - BATAS_DISKON) * x.kotor).sum()
    skenario = dict(
        tagih=dict(n=len(tinggi_sedang), harapan=harapan, efek=ASUMSI_EFEK, selamat=harapan * ASUMSI_EFEK),
        diskon=dict(batas=BATAS_DISKON, margin=MARGIN_TIPIS, n=len(x), hemat=hemat, batal=ASUMSI_BATAL,
                    dampak=(1 - ASUMSI_BATAL) * hemat - ASUMSI_BATAL * (x.bersih - x.hpp).sum(),
                    impas=hemat / (hemat + (x.bersih - x.hpp).sum())))
    return dict(top=top, pelanggan=plg.to_dict("records"), skenario=skenario,
                tingkat={t: int((baru.tingkat == t).sum()) for t in ("Tinggi", "Sedang", "Rendah")},
                nilai_tingkat={t: float(baru[baru.tingkat == t].bersih.sum()) for t in ("Tinggi", "Sedang", "Rendah")})


# ---------------------------------------------------------------- 6. DEPLOYMENT
def js(o):
    s = json.dumps(o, ensure_ascii=False, default=lambda x: x.item() if hasattr(x, "item") else str(x))
    return s.replace("</", "<\\/")


def main():
    buat_data_mentah()
    d, antrean, log = bersihkan()
    m = keuangan(d)
    A, B = m.iloc[:12], m.iloc[12:]
    lab, baru, info = prediktif(d)
    ringkas = dict(pend_A=A.bersih.sum(), pend_B=B.bersih.sum(), laba_A=A.laba.sum(), laba_B=B.laba.sum(),
                   dso_A=A.dso.mean(), dso_B=B.dso.mean(), piutang=m.piutang.iloc[-1], n_invoice=len(d),
                   n_pelanggan=d.pelanggan.nunique())
    hasil = dict(meta=dict(diperbarui=datetime.now().strftime("%d %b %Y %H:%M"), cutoff=CUTOFF.strftime("%d %b %Y")),
                 ringkas=ringkas, bulanan=m.round(0).to_dict("records"), aging=aging(d), log=log,
                 diag=diagnostik(d, m), model=info, preskripsi=preskriptif(d, lab, baru),
                 antrean=antrean.head(15).to_dict("records"), n_antrean=len(antrean))
    DOCS.mkdir(exist_ok=True)
    (DOCS / ".nojekyll").touch()
    d.drop(columns=["tanggal_invoice", "tanggal_bayar", "harga_satuan", "_k"]).to_csv(DOCS / "data_bersih.csv", index=False)
    baru[["no_invoice", "pelanggan", "produk", "bersih", "jt", "proba", "tingkat"]].assign(proba=baru.proba.round(3)).to_csv(DOCS / "prediksi_invoice.csv", index=False)
    (DOCS / "index.html").write_text(TEMPLATE.replace("__DATA__", js(hasil)), encoding="utf-8")
    print(f"Selesai: {len(d)} invoice bersih, {len(antrean)} menunggu verifikasi, model terbaik {info['terbaik']}")
    print(f"Pendapatan A->B: {A.bersih.sum()/1e9:.2f} -> {B.bersih.sum()/1e9:.2f} M | Laba A->B: {A.laba.sum()/1e9:.2f} -> {B.laba.sum()/1e9:.2f} M")


TEMPLATE = r'''<!DOCTYPE html><html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>PT Maju Bersama: omzet naik, laba turun</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;600;800&display=swap">
<style>
:root{--kertas:#eef2f5;--tinta:#16243a;--muted:#55667b;--garis:#c5cfd9;--teal:#0b7a83;--merah:#c0304a;--amber:#b7791f;--tealp:#d6ebec;--merahp:#f6dde2;--ambp:#f5e8cc}
*{box-sizing:border-box}body{margin:0;background:var(--kertas);color:var(--tinta);font:16px/1.55 "Schibsted Grotesk",system-ui,-apple-system,"Segoe UI",Arial,sans-serif}
.wrap{max-width:1080px;margin:auto;padding:0 24px}
nav{position:sticky;top:0;z-index:5;background:var(--kertas);border-bottom:1px solid var(--garis)}
nav .wrap{display:flex;gap:24px;overflow-x:auto;padding:12px 24px;font-size:.9rem;font-weight:600;white-space:nowrap}
nav a{color:var(--muted);text-decoration:none}nav a:hover,nav a:focus-visible{color:var(--tinta);text-decoration:underline;text-underline-offset:5px}
header{padding:52px 0 36px}
.chip{display:inline-block;border:1.5px solid var(--tinta);padding:2px 10px;font-size:.82rem;font-weight:600;margin-bottom:18px}
h1{margin:0 0 16px;font-size:clamp(2rem,5.4vw,3.6rem);line-height:1.04;letter-spacing:-.028em;font-weight:800;max-width:18em}
.lead{max-width:62ch;margin:0 0 30px;color:var(--muted);font-size:1.05rem}
.kpi{display:grid;grid-template-columns:repeat(4,1fr);border-top:2px solid var(--tinta);margin-bottom:34px}
.kpi div{padding:14px 16px 4px 0}.kpi div+div{padding-left:18px;border-left:1px solid var(--garis)}
.kpi small{display:block;color:var(--muted);font-size:.85rem}.kpi b{display:block;font-size:1.9rem;letter-spacing:-.02em;line-height:1.2}.kpi em{font-style:normal;font-weight:600;font-size:.88rem}
.neg{color:var(--merah)}.pos{color:var(--teal)}
.chart svg{width:100%;height:auto;display:block}.gl{stroke:var(--garis);stroke-width:1}.ax{fill:var(--muted);font-size:12px}.lg{display:flex;flex-wrap:wrap;gap:6px 22px;font-size:.88rem;font-weight:600;margin-bottom:6px}.lg .note{font-weight:400}.lg i{display:inline-block;width:22px;height:4px;vertical-align:middle;margin-right:7px}
.alur{display:flex;flex-wrap:wrap;gap:6px 26px;margin:30px 0 0;padding:0;list-style:none;counter-reset:s;font-size:.88rem;font-weight:600;color:var(--muted)}
.alur li{counter-increment:s}.alur li::before{content:counter(s)". ";color:var(--tinta)}
section{display:grid;grid-template-columns:210px minmax(0,1fr);gap:34px;padding:44px 0;border-top:2px solid var(--tinta)}
section h2{margin:0;font-size:1.5rem;letter-spacing:-.015em;line-height:1.15}section .q{margin:8px 0 0;color:var(--muted);font-size:.95rem}
section h3{margin:30px 0 8px;font-size:1.02rem}section h3:first-child{margin-top:0}
p{margin:0 0 14px;max-width:70ch}.note{color:var(--muted);font-size:.9rem}
.tw{overflow-x:auto;margin:6px 0 18px}table{border-collapse:collapse;width:100%;font-size:.9rem}
th{text-align:left;font-weight:600;font-size:.8rem;color:var(--muted);padding:6px 12px 6px 0;border-bottom:2px solid var(--tinta);white-space:nowrap}
td{padding:8px 12px 8px 0;border-bottom:1px solid var(--garis);vertical-align:top}.r{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.n,td:first-child{white-space:nowrap}
tr.best td{background:var(--tealp);font-weight:600}
.pill{display:inline-block;padding:1px 9px;font-weight:600;font-size:.8rem}.pill.Tinggi{background:var(--merahp);color:#8c1d33}.pill.Sedang{background:var(--ambp);color:#7a4f0a}.pill.Rendah{background:var(--tealp);color:#075359}
.wf{display:grid;grid-template-columns:240px 1fr 120px;gap:12px;align-items:center;padding:7px 0;border-bottom:1px solid var(--garis);font-size:.9rem}
.wf b{text-align:right;font-variant-numeric:tabular-nums}.trk{position:relative;height:18px}.trk i{position:absolute;top:0;bottom:0;min-width:2px}
.br{display:grid;grid-template-columns:130px 1fr 90px;gap:12px;align-items:center;font-size:.9rem;padding:5px 0}.br i{display:block;height:16px;background:var(--teal);min-width:2px}.br b{text-align:right;font-variant-numeric:tabular-nums}
.tier{display:grid;grid-template-columns:repeat(3,1fr);margin:6px 0 22px;border-top:2px solid var(--tinta)}.tier div{padding:12px 14px 4px 0}.tier div+div{padding-left:16px;border-left:1px solid var(--garis)}.tier b{display:block;font-size:1.7rem}.tier small{color:var(--muted)}
.two{display:grid;grid-template-columns:1fr 1fr;gap:28px}.two h3{margin-top:0}ul{margin:0;padding-left:18px}li{margin-bottom:6px}
.skn{border-top:1px solid var(--garis);padding:14px 0}.skn b{font-size:1.25rem}.skn p{margin:4px 0 0}
footer{border-top:2px solid var(--tinta);padding:26px 0 60px;font-size:.88rem;color:var(--muted)}
@media(max-width:860px){section{grid-template-columns:minmax(0,1fr);gap:16px}.kpi{grid-template-columns:1fr 1fr}.kpi div:nth-child(3){border-left:0;padding-left:0}.two{grid-template-columns:1fr}.kpi b{font-size:1.45rem}.tier{grid-template-columns:1fr}.tier div+div{border-left:0;padding-left:0;border-top:1px solid var(--garis)}.wf{grid-template-columns:1fr 1fr}.wf .trk{grid-column:1/3;order:3}.br{grid-template-columns:100px 1fr 70px}}
@media(prefers-reduced-motion:no-preference){.chart .draw{stroke-dasharray:2400;stroke-dashoffset:2400;animation:d 1.6s ease-out forwards}@keyframes d{to{stroke-dashoffset:0}}}
</style></head><body>
<nav><div class="wrap"><a href="#top">Ringkasan</a><a href="#data">Persiapan data</a><a href="#deskriptif">Deskriptif</a><a href="#diagnostik">Diagnostik</a><a href="#prediktif">Prediktif</a><a href="#preskriptif">Preskriptif</a><a href="#manusia">Peran manusia</a></div></nav>
<div class="wrap"><header id="top"><span class="chip">Studi kasus fiktif dengan data sintetis</span>
<h1 id="judul"></h1><p class="lead" id="lead"></p><div class="kpi" id="kpi"></div>
<div class="chart"><div class="lg"><span><i style="background:var(--teal)"></i>Pendapatan bersih</span><span><i style="background:var(--merah)"></i>Laba bersih</span><span class="note">Indeks rata-rata 3 bulan, bulan ke-3 = 100. Area merah muda adalah jurang antara keduanya.</span></div><div id="hero"></div></div>
<ol class="alur"><li>Memahami masalah bisnis</li><li>Memahami data</li><li>Menyiapkan data</li><li>Memodelkan</li><li>Mengevaluasi</li><li>Menyajikan dan menjalankan otomatis</li></ol></header>

<section id="data"><div><h2>Persiapan data</h2><p class="q">Seberapa berantakan data aslinya, dan apa yang dilakukan?</p></div><div>
<p>Tahap ini memakan sebagian besar waktu kerja. Data mentah (<code>data/data_mentah.csv</code>) sengaja dibuat berantakan seperti data lapangan. Setiap perbaikan dicatat, dan baris yang meragukan tidak dibuang diam-diam.</p><div id="log"></div></div></section>

<section id="deskriptif"><div><h2>Deskriptif</h2><p class="q">Apa yang telah terjadi?</p></div><div>
<h3>Piutang terbuka akhir bulan</h3><div class="chart" id="piut"></div>
<h3>Rata-rata hari penagihan (DSO)</h3><div class="chart" id="dso"></div>
<h3>Umur piutang pada <span id="cut"></span></h3><div id="aging"></div></div></section>

<section id="diagnostik"><div><h2>Diagnostik</h2><p class="q">Mengapa laba turun padahal penjualan naik?</p></div><div>
<h3>Dari laba 12 bulan pertama ke 12 bulan terakhir</h3><div id="wf"></div><p id="t_wf" style="margin-top:14px"></p>
<h3>Margin per produk (setelah diskon)</h3><div id="t_prod"></div><p id="n_prod"></p>
<h3>Diskon dan kedisiplinan bayar per segmen</h3><div id="t_seg"></div><p id="n_seg"></p></div></section>

<section id="prediktif"><div><h2>Prediktif</h2><p class="q">Invoice mana yang berpotensi dibayar terlambat?</p></div><div>
<p id="n_model"></p><div id="t_model"></div>
<h3>Invoice terbuka yang belum jatuh tempo</h3><div class="tier" id="tier"></div></div></section>

<section id="preskriptif"><div><h2>Preskriptif</h2><p class="q">Tindakan apa yang sebaiknya diambil?</p></div><div>
<h3>Invoice yang perlu ditangani lebih dulu</h3><div id="t_top"></div>
<h3>Pelanggan yang perlu perhatian</h3><div id="t_plg"></div>
<h3>Simulasi kebijakan</h3><div id="skn"></div></div></section>

<section id="manusia"><div><h2>Peran manusia</h2><p class="q">Apa yang tidak boleh diserahkan ke mesin?</p></div><div>
<h3>Antrean verifikasi (<span id="nq"></span> invoice)</h3><p>Baris ini dikeluarkan dari analisis sampai ada orang yang memeriksa sumbernya. Berikut 15 teratas.</p><div id="t_q"></div>
<div class="two"><div><h3>Dikerjakan pipeline</h3><ul><li>Membersihkan format dan duplikat</li><li>Menghitung metrik dan membandingkan model</li><li>Mengurutkan invoice berdasarkan risiko</li></ul></div>
<div><h3>Diputuskan manusia</h3><ul><li>Apakah anomali itu salah input atau transaksi nyata</li><li>Apakah penagihan keras layak dilakukan ke pelanggan strategis</li><li>Apakah asumsi simulasi kebijakan masuk akal</li><li>Kebijakan diskon dan termin yang akhirnya dipakai</li></ul></div></div></div></section>
<footer>Semua data adalah hasil simulasi dan tidak mewakili perusahaan nyata. Diperbarui <span id="upd"></span>. Kode dan data olahan ada di repositori GitHub: <code>pipeline_analitik.py</code>, <code>docs/data_bersih.csv</code>, <code>docs/prediksi_invoice.csv</code>. Studi kasus berdasarkan kuliah praktisi oleh Andria Arisal (BRIN).</footer></div>
<script>
const D=__DATA__,$=i=>document.getElementById(i),R=D.ringkas,M=D.bulanan,DG=D.diag,P=D.preskripsi;
const nf=(x,d=0)=>x.toLocaleString('id-ID',{maximumFractionDigits:d,minimumFractionDigits:d});
const rp=x=>{const a=Math.abs(x);return(x<0?'−':'')+'Rp '+(a>=1e9?nf(a/1e9,2)+' M':nf(a/1e6,0)+' jt')};
const pct=(x,d=0)=>nf(x*100,d)+'%',pp=x=>(x>0?'+':'')+nf(x*100,1)+' poin',sum=(a,k)=>a.reduce((s,r)=>s+r[k],0);
const tbl=(h,rows,al=[],cls=[])=>`<div class="tw"><table><thead><tr>${h.map((x,i)=>`<th class="${al[i]||''}">${x}</th>`).join('')}</tr></thead><tbody>${rows.map((r,j)=>`<tr class="${cls[j]||''}">${r.map((c,i)=>`<td class="${al[i]||''}">${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
function line(el,labels,S,o={}){
 const W=900,H=o.h||320,L=48,Rt=96,T=14,B=30,all=S.flatMap(s=>s.v);let lo=o.lo??Math.min(...all),hi=Math.max(...all);const pd=(hi-lo)*.1;lo-=o.lo!==undefined?0:pd;hi+=pd;
 const n=labels.length,x=i=>L+i*(W-L-Rt)/(n-1),y=v=>H-B-(v-lo)/(hi-lo)*(H-T-B),f=o.fy||(v=>nf(v));let g='';
 for(let k=0;k<=4;k++){const v=lo+(hi-lo)*k/4;g+=`<line x1="${L}" x2="${W-Rt}" y1="${y(v)}" y2="${y(v)}" class="gl"/><text x="${L-8}" y="${y(v)+4}" class="ax" text-anchor="end">${f(v)}</text>`}
 labels.forEach((l,i)=>{if((n-1-i)%3===0)g+=`<text x="${x(i)}" y="${H-8}" class="ax" text-anchor="middle">${l}</text>`});
 const path=v=>v.map((a,i)=>(i?'L':'M')+x(i).toFixed(1)+' '+y(a).toFixed(1)).join('');
 if(o.gap)g+=`<path d="${path(S[0].v)}${S[1].v.map((a,i)=>'L'+x(n-1-i).toFixed(1)+' '+y(S[1].v[n-1-i]).toFixed(1)).join('')}Z" fill="#c0304a" opacity=".13"/>`;
 S.forEach(s=>{g+=`<path class="draw" d="${path(s.v)}" fill="none" stroke="${s.c}" stroke-width="3" stroke-linejoin="round"/><text x="${x(n-1)+8}" y="${y(s.v[n-1])+4}" font-size="13" font-weight="700" fill="${s.c}">${f(s.v[n-1])}</text>`});
 $(el).innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${o.label||'grafik'}">${g}</svg>`}
function cols(el,labels,v,c,f,label){const W=900,H=260,L=48,T=14,B=30,hi=Math.max(...v)*1.1,w=(W-L-20)/v.length;let g='';
 for(let k=0;k<=4;k++){const a=hi*k/4,yy=H-B-a/hi*(H-T-B);g+=`<line x1="${L}" x2="${W-20}" y1="${yy}" y2="${yy}" class="gl"/><text x="${L-8}" y="${yy+4}" class="ax" text-anchor="end">${f(a)}</text>`}
 v.forEach((a,i)=>{const h=a/hi*(H-T-B);g+=`<rect x="${L+i*w+w*.15}" y="${H-B-h}" width="${w*.7}" height="${h}" fill="${c}"/>`;if((v.length-1-i)%3===0)g+=`<text x="${L+i*w+w/2}" y="${H-8}" class="ax" text-anchor="middle">${labels[i]}</text>`});
 $(el).innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${label}">${g}</svg>`}
const A=M.slice(0,12),B=M.slice(12),mg=a=>(sum(a,'bersih')-sum(a,'hpp'))/sum(a,'bersih'),ox=a=>sum(a,'opex')/sum(a,'bersih');
const gr=R.pend_B/R.pend_A-1,gl=R.laba_B/R.laba_A-1;
$('judul').textContent=`Pendapatan naik ${pct(gr)}, tetapi laba bersih turun ${pct(-gl)}`;
$('lead').textContent=`PT Maju Bersama (perusahaan fiktif) menjual perangkat jaringan, server, lisensi, dan jasa TI. Angka di bawah membandingkan 12 bulan terakhir dengan 12 bulan sebelumnya. Dari ${nf(R.n_invoice)} invoice yang berantakan, pertanyaannya: apa yang terjadi, mengapa, apa yang akan terjadi, dan apa yang harus dilakukan?`;
$('kpi').innerHTML=[['Pendapatan bersih, 12 bulan terakhir',rp(R.pend_B),`+${pct(gr)} dari periode sebelumnya`,'pos'],['Laba bersih, 12 bulan terakhir',rp(R.laba_B),`${pct(gl)} dari periode sebelumnya`,'neg'],['Piutang terbuka',rp(R.piutang),`akhir ${M[M.length-1].bulan}`,''],['Lama penagihan (DSO)',nf(R.dso_B,0)+' hari',`sebelumnya ${nf(R.dso_A,0)} hari`,'neg']].map(k=>`<div><small>${k[0]}</small><b>${k[1]}</b><em class="${k[3]}">${k[2]}</em></div>`).join('');
const ma=k=>M.map((_,i)=>i<2?null:(M[i][k]+M[i-1][k]+M[i-2][k])/3).slice(2),a1=ma('bersih'),a2=ma('laba');
line('hero',M.slice(2).map(r=>r.bulan),[{v:a1.map(v=>v/a1[0]*100),c:'#0b7a83'},{v:a2.map(v=>v/a2[0]*100),c:'#c0304a'}],{gap:1,h:340,label:'Indeks pendapatan dan laba bersih'});
$('log').innerHTML=tbl(['Tahap','Temuan','Tindakan','Baris'],D.log.map(l=>[l.tahap,l.temuan,l.tindakan,nf(l.jumlah)]),['','','','r']);
cols('piut',M.map(r=>r.bulan),M.map(r=>r.piutang),'#b7791f',v=>nf(v/1e9,1)+' M','Piutang terbuka per bulan');
line('dso',M.map(r=>r.bulan),[{v:M.map(r=>r.dso),c:'#16243a'}],{lo:0,h:240,fy:v=>nf(v,0),label:'DSO per bulan'});
$('cut').textContent=D.meta.cutoff;const ag=Object.entries(D.aging),mxa=Math.max(...ag.map(a=>a[1]));
$('aging').innerHTML=ag.map(([k,v])=>`<div class="br"><span>${k}</span><i style="width:${v/mxa*100}%;background:${k==='Belum jatuh tempo'?'var(--teal)':'var(--merah)'}"></i><b>${rp(v)}</b></div>`).join('');
let c=0;const W=DG.waterfall.map(w=>{let a,b;if(w.tipe==='total'){a=0;b=w.nilai;c=b}else{a=c;b=c+w.nilai;c=b}return{...w,a,b}}),mx=Math.max(...W.flatMap(r=>[r.a,r.b]));
$('wf').innerHTML=W.map(r=>`<div class="wf"><span>${r.label}</span><div class="trk"><i style="left:${Math.min(r.a,r.b)/mx*100}%;width:${Math.abs(r.b-r.a)/mx*100}%;background:${r.tipe==='total'?'var(--tinta)':r.nilai>=0?'var(--teal)':'var(--merah)'}"></i></div><b class="${r.tipe!=='total'&&r.nilai<0?'neg':''}">${r.tipe!=='total'&&r.nilai>0?'+':''}${rp(r.nilai)}</b></div>`).join('');
$('t_wf').textContent=`Penjualan bertambah, tetapi margin kotor setelah diskon turun dari ${pct(mg(A),1)} menjadi ${pct(mg(B),1)}, dan biaya operasional naik dari ${pct(ox(A),1)} menjadi ${pct(ox(B),1)} dari pendapatan. Penyisihan piutang masih kecil, jadi dampak piutang saat ini lebih pada kas yang tertahan daripada pada laba.`;
$('t_prod').innerHTML=tbl(['Produk','Margin periode lalu','Margin 12 bln terakhir','Perubahan'],DG.produk.map(p=>[p.produk,pct(p.marginA,1),pct(p.marginB,1),`<span class="${p.marginB<p.marginA-.02?'neg':''}">${pp(p.marginB-p.marginA)}</span>`]),['','r','r','r']);
const pw=[...DG.produk].sort((a,b)=>(a.marginB-a.marginA)-(b.marginB-b.marginA))[0];
$('n_prod').textContent=`Penurunan terbesar ada pada ${pw.produk} (${pp(pw.marginB-pw.marginA)}). Harga pokoknya naik lebih cepat daripada harga jual, sementara volumenya terus bertambah.`;
$('t_seg').innerHTML=tbl(['Segmen','Diskon rata-rata','Invoice telat bayar','Rata-rata hari telat'],DG.segmen.map(s=>[s.segmen,`${pct(s.diskonA,1)} → ${pct(s.diskonB,1)}`,`${pct(s.telatA)} → ${pct(s.telatB)}`,`${nf(s.hariA,0)} → ${nf(s.hariB,0)} hari`]),['','r','r','r']);
const kor=DG.segmen.find(s=>s.segmen==='Korporasi'),pem=DG.segmen.find(s=>s.segmen==='Pemerintah');
$('n_seg').textContent=`Diskon segmen Korporasi naik dari ${pct(kor.diskonA,1)} ke ${pct(kor.diskonB,1)}. Segmen Pemerintah membayar makin lambat: invoice yang telat naik dari ${pct(pem.telatA)} ke ${pct(pem.telatB)}. Angka ini hanya mencakup invoice yang sudah jatuh tempo.`;
const MD=D.model,bs=MD.terbaik;
$('n_model').textContent=`Empat model dibandingkan berdampingan pada ${nf(MD.n_uji)} invoice paling baru (pembagian berdasarkan waktu, bukan acak). Sebanyak ${pct(MD.proporsi_telat)} invoice berlabel telat. Tebakan "selalu begitu" saja sudah mencapai akurasi ${pct(MD.baseline)}, jadi model dinilai terutama dari AUC. Model terbaik, ${bs}, dilatih ulang pada semua data berlabel.`;
$('t_model').innerHTML=tbl(['Model','Akurasi','Presisi','Recall','F1','AUC'],MD.hasil.map(m=>[m.model,pct(m.akurasi),pct(m.presisi),pct(m.recall),nf(m.f1,2),nf(m.auc,3)]),['','r','r','r','r','r'],MD.hasil.map(m=>m.model===bs?'best':''));
$('tier').innerHTML=['Tinggi','Sedang','Rendah'].map(t=>`<div><span class="pill ${t}">Risiko ${t.toLowerCase()}</span><b>${P.tingkat[t]} invoice</b><small>${rp(P.nilai_tingkat[t])}</small></div>`).join('');
$('t_top').innerHTML=tbl(['Invoice','Pelanggan','Nilai','Jatuh tempo','Peluang telat','Tindakan'],P.top.map(t=>[t.no,t.pelanggan,rp(t.nilai),t.jt,`<span class="pill ${t.tingkat}">${pct(t.proba)}</span>`,t.tindakan]),['n','','r','n','','']);
$('t_plg').innerHTML=tbl(['Pelanggan','Segmen','Riwayat telat','Piutang terbuka','Diperkirakan telat','Saran'],P.pelanggan.map(p=>[p.pelanggan,p.segmen,pct(p.rate),rp(p.terbuka),rp(p.berisiko),p.saran]),['','','r','r','r','']);
const S=P.skenario;
$('skn').innerHTML=`<div class="skn"><b>${rp(S.tagih.selamat)}</b><p>Penagihan proaktif pada ${S.tagih.n} invoice berisiko sedang dan tinggi (nilai harapan telat ${rp(S.tagih.harapan)}). <span class="note">Asumsi: tindakan menurunkan peluang telat sebesar ${pct(S.tagih.efek)}.</span></p></div>
<div class="skn"><b class="${S.diskon.dampak<0?'neg':'pos'}">${S.diskon.dampak>0?'+':''}${rp(S.diskon.dampak)} laba</b><p>Membatasi diskon maksimal ${pct(S.diskon.batas)} pada ${S.diskon.n} invoice yang margin setelah diskonnya di bawah ${pct(S.diskon.margin)} (12 bulan terakhir). <span class="note">Asumsi: ${pct(S.diskon.batal)} dari invoice itu batal. Kebijakan ini tetap menguntungkan selama pembatalan di bawah ${pct(S.diskon.impas,1)}.</span></p></div>`;
$('nq').textContent=nf(D.n_antrean);$('t_q').innerHTML=tbl(['Invoice','Pelanggan','Produk','Qty','Harga satuan','Alasan'],D.antrean.map(a=>[a.no_invoice,a.pelanggan,a.produk,nf(a.qty),rp(a.harga),a.flag]),['n','','','r','r','']);
$('upd').textContent=D.meta.diperbarui;
</script></body></html>
'''

if __name__ == "__main__":
    main()
